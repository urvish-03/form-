import React, { useState } from "react";

function Form(props) {
  const [validationMessages, setValidationMessages] = useState([]);
  const [formData, setFormData] = useState({});
  const handleChange = ({ target }) => {
    setFormData({ ...formData, [target.name]: target.value });
  };
  const handleClick = (evt) => {
    validateForm();
    if (validationMessages.length > 0) {
      evt.preventDefault();
    }
  };
  const validateForm = () => {
    const { firstName, lastName, DOB, email, sbio } = formData;
    setValidationMessages([]);
    let messages = [];
    if (!firstName) {
      messages.push("First Name is required");
    }
    if (!lastName) {
      messages.push("Last Name is required");
    }
    if (!email) {
      messages.push("Please select a Gender");
    }
    if (!DOB) {
      messages.push("Date of Birth is required");
    }
    if (!sbio) {
      messages.push("Short BIO is required");
    }
    setValidationMessages(messages);
  };
  return (
    <>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          height: "60vh",
          width: "100vw",
        }}
      >
        <form style={{ display: "flex", flexDirection: "column" }}>
          <label>First Name</label>
          <input
            value={formData.firstName || ""}
            onChange={handleChange}
            type="text"
            name="firstName"
          />
          <label>Last Name</label>
          <input
            value={formData.lastName || ""}
            onChange={handleChange}
            type="text"
            name="lastName"
          />
          <label>Email</label>
          <input
            value={formData.email || ""}
            onChange={handleChange}
            type="text"
            name="email"
          />
          <label>Date of Birth</label>
          <input
            value={formData.DOB || ""}
            onChange={handleChange}
            type="date"
            name="DOB"
          />
          <label>Short Bio</label>
          <input
            value={formData.sbio || ""}
            onChange={handleChange}
            type="text"
            name="sbio"
          />
          <br />
          <button type="button" onClick={handleClick}>
            Save
          </button>
        </form>

        <div>
          {validationMessages.length > 0}
          <ul>
            {validationMessages.map((vm) => (
              <li key={vm}>{vm}</li>
            ))}
          </ul>
        </div>
      </div>
    </>
  );
}

export default Form;
