import React from "react";

import { NavLink } from "react-router-dom";
const Home = () => {
  return (
    <div>
      <h1>Home</h1>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div
          style={{
            margin: "20px",
            textDecoration: "none",
            fontSize: "20px",
          }}
        >
          <NavLink to="/Form">Form</NavLink>
        </div>
        <div
          style={{
            margin: "20px",
            textDecoration: "none",
            fontSize: "20px",
          }}
        >
          <NavLink to="/View">View</NavLink>
        </div>
      </div>
    </div>
  );
};

export default Home;
