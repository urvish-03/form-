import React from "react";

const View = () => {
  return <h2>View</h2>;
};

export default View;
