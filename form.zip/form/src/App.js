import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Form from "./Component/Form";
import View from "./Component/View";
import Home from "./Component/Home";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Home />
        <Routes>
          <Route path="/Form" element={<Form />} />
          <Route path="/view" element={<View />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
